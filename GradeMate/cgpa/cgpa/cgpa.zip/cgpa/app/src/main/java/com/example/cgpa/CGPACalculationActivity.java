package com.example.cgpa;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class CGPACalculationActivity extends AppCompatActivity {
    EditText[] grades;
    TextView resultText;
    Button calculateButton;
    int numCourses;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cgpa_calculation);

        resultText = findViewById(R.id.result_text);
        calculateButton = findViewById(R.id.calculate_button);

        int semester = getIntent().getIntExtra("semester", 1);
        configureCourseInputs(semester);  // Set course inputs based on semester

        calculateButton.setOnClickListener(v -> calculateCGPA(semester));
    }

    private void configureCourseInputs(int semester) {
        if (semester == 1) {
            numCourses = 5; // Example: 5 courses for semester 1
            grades = new EditText[numCourses];
            grades[0] = findViewById(R.id.grade1);
            grades[1] = findViewById(R.id.grade2);
            grades[2] = findViewById(R.id.grade3);
            grades[3] = findViewById(R.id.grade4);
            grades[4] = findViewById(R.id.grade5);
        } else if (semester == 2) {
            numCourses = 6; // Example: 6 courses for semester 2
            grades = new EditText[numCourses];
            grades[0] = findViewById(R.id.grade1);
            grades[1] = findViewById(R.id.grade2);
            grades[2] = findViewById(R.id.grade3);
            grades[3] = findViewById(R.id.grade4);
            grades[4] = findViewById(R.id.grade5);
            grades[5] = findViewById(R.id.grade6);
        }
        // Add more semesters with their respective courses here
    }

    private void calculateCGPA(int semester) {
        try {
            double totalGradePoints = 0;
            double totalCredits = 0;
            float[] credits = getCreditsForSemester(semester);

            for (int i = 0; i < numCourses; i++) {
                double gradePoint = getGradePoint(grades[i].getText().toString());
                totalGradePoints += gradePoint * credits[i];
                totalCredits += credits[i];
            }

            double cgpa = totalGradePoints / totalCredits;
            resultText.setText("Your CGPA: " + String.format("%.2f", cgpa));

        } catch (Exception e) {
            Toast.makeText(CGPACalculationActivity.this, "Please enter valid grades!", Toast.LENGTH_SHORT).show();
        }
    }

    // Helper method to convert grades to grade points
    private double getGradePoint(String grade) {
        switch (grade.toUpperCase()) {
            case "O":
                return 10;
            case "A":
                return 9;
            case "B":
                return 8;
            case "C":
                return 7;
            case "D":
                return 6;
            case "FAIL":
                return 0;
            default:
                throw new IllegalArgumentException("Invalid grade entered");
        }
    }

    // Method to fetch credits for each course based on the selected semester
    private float[] getCreditsForSemester(int semester) {
        switch (semester) {
            case 1:
                return new float[]{2, 3, 4, 3, 3}; // Example credits for semester 1
            case 2:
                return new float[]{1.5f, 3, 4, 2, 3, 2.5f}; // Example credits for semester 2
            // Add more semesters with specific credits
            default:
                return new float[]{3, 3, 3, 3, 3}; // Default credits if semester not specified
        }
    }
}
