package com.example.cgpa;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class SemesterActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_semester);

        Button sem1Button = findViewById(R.id.sem1_button);
        Button sem2Button = findViewById(R.id.sem2_button);
        // Add more buttons for other semesters as needed

        sem1Button.setOnClickListener(v -> {
            Intent intent = new Intent(SemesterActivity.this, CGPACalculationActivity.class);
            intent.putExtra("semester", 1); // Pass semester 1
            startActivity(intent);
        });

        sem2Button.setOnClickListener(v -> {
            Intent intent = new Intent(SemesterActivity.this, CGPACalculationActivity.class);
            intent.putExtra("semester", 2); // Pass semester 2
            startActivity(intent);
        });

        // Add click listeners for other semester buttons
    }
}
